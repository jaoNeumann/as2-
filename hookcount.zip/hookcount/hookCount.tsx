import React, { useState } from 'react';
import './hookCount.css'; // Importando o CSS

const ProgressBar = () => {
  const [progress, setProgress] = useState(0);
  const maxProgress = 1; // Define o valor máximo de progresso

  const increaseProgress = () => {
    // Aumenta o progresso em 25% (0.25)
    const newProgress = progress + 0.25;
    setProgress(newProgress);

    // Desativa o botão quando o progresso atinge o máximo
    if (newProgress >= maxProgress) {
      setProgress(maxProgress); // Garante que o progresso não exceda o máximo
    }
  };

  return (
    <div>
      <div className="progress-bar-container">
        <div className="progress-bar">
          <div
            className="progress"
            style={{
              width: `${progress * 100}%`,
            }}
          ></div>
        </div>
      </div>
      <div className="button-container">
        <button onClick={increaseProgress} disabled={progress >= maxProgress}>
          Increase progress
        </button>
      </div>
    </div>
  );
};

export default ProgressBar;
